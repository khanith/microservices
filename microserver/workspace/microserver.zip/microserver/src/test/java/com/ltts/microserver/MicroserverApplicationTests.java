package com.ltts.microserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
