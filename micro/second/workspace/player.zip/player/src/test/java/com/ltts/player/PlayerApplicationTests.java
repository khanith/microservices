package com.ltts.player;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlayerApplicationTests {

	@Test
	void contextLoads() {
	}

}
